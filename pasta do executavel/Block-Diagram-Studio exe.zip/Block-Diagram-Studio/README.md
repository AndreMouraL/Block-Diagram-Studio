# Block-Diagram-Studio

#OBS: caso a inicialização não ocorra, execute o arquivo 'Bibliotecas.bat'.